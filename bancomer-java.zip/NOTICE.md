
This product includes software developed by:

Opencard Inc.

The Apache Software Foundation (http://www.apache.org/).