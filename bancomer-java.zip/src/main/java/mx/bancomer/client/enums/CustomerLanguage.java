package mx.bancomer.client.enums;

public enum CustomerLanguage {
    /** Spanish */
    SP,
    /** English */
    EN
}
