package mx.bancomer.client;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Token {

    private String id;

    private Card card;

}
